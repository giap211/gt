"use client";

import { useEffect, useState, use } from "react";
import { InfiniteMovieGrid } from "@/components/infinite-movie-grid";
import { FilterBar } from "@/components/filter-bar";
import {
  getMoviesByCategory,
  searchMovies,
  type ListMovie,
  type LatestMoviesResponse,
} from "@/lib/ophim-client";

// Chủ đề đặc biệt (TopicGrid) → dùng tìm kiếm, không phải slug thể loại API
const TOPIC_SEARCH_KEYWORDS: Record<string, string> = {
  marvel: "marvel",
  sitcom: "sitcom",
  "long-tieng": "lồng tiếng",
  "xuyen-khong": "xuyên không",
  "nhuc-dau": "kinh dị",
};

const categoryMap: Record<string, string> = {
  marvel: "Phim Marvel",
  sitcom: "Sitcom",
  "long-tieng": "Lồng Tiếng Cực Mạnh",
  "xuyen-khong": "Xuyên Không",
  "nhuc-dau": "Phim Nhức Đầu",
  "hanh-dong": "Phim Hành Động",
  "tinh-cam": "Phim Tình Cảm",
  "hai-huoc": "Phim Hài Hước",
  "co-trang": "Phim Cổ Trang",
  "tam-ly": "Phim Tâm Lý",
  "hinh-su": "Phim Hình Sự",
  "chien-tranh": "Phim Chiến Tranh",
  "the-thao": "Phim Thể Thao",
  "vo-thuat": "Phim Võ Thuật",
  "vien-tuong": "Phim Viễn Tưởng",
  "phieu-luu": "Phim Phiêu Lưu",
  "khoa-hoc": "Phim Khoa Học",
  "kinh-di": "Phim Kinh Dị",
  "am-nhac": "Phim Âm Nhạc",
  "than-thoai": "Phim Thần Thoại",
  "tai-lieu": "Phim Tài Liệu",
  "gia-dinh": "Phim Gia Đình",
  "chinh-kich": "Phim Chính Kịch",
  "bi-an": "Phim Bí Ẩn",
  "hoc-duong": "Phim Học Đường",
  "kinh-dien": "Phim Kinh Điển",
  "hoat-hinh": "Phim Hoạt Hình",
  "chieu-rap": "Phim Chiếu Rạp",
  "hoi-hop": "Phim Hồi Hộp",
};

async function fetchBySlug(
  slug: string,
  page: number,
): Promise<LatestMoviesResponse> {
  const keyword = TOPIC_SEARCH_KEYWORDS[slug];
  if (keyword) {
    return searchMovies(keyword, page, 24);
  }
  return getMoviesByCategory(slug, page);
}

export default function CategoryPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = use(params);
  const [movies, setMovies] = useState<ListMovie[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalPages, setTotalPages] = useState(1);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const pages = [1, 2, 3];
        const responses = await Promise.all(
          pages.map((p) => fetchBySlug(slug, p)),
        );

        const validResults = responses.filter((r) => r && r.status);
        if (validResults.length > 0) {
          let allItems: ListMovie[] = [];
          validResults.forEach((res) => {
            allItems = [...allItems, ...res.items];
          });

          const unique = Array.from(
            new Map(allItems.map((m) => [m._id, m])).values(),
          );

          setMovies(unique.slice(0, 200));
          const firstRes = validResults[0];
          if (firstRes?.pagination) {
            setTotalPages(firstRes.pagination.totalPages || 1);
          }
        } else {
          setMovies([]);
          setTotalPages(1);
        }
      } catch (error) {
        console.error("Failed to fetch category listing", error);
        setMovies([]);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [slug]);

  return (
    <main className="min-h-screen bg-[#0b0d14] text-white">
      <div className="pt-24 container mx-auto px-4 lg:px-8 pb-20">
        <div className="mb-8 flex items-center gap-3">
          <div className="w-1.5 h-8 bg-[#ffd875] rounded-full shadow-[0_0_10px_rgba(255,216,117,0.3)]"></div>
          <h1 className="text-3xl font-bold tracking-tight uppercase">
            {categoryMap[slug] || `Phim ${slug}`}
          </h1>
        </div>

        <FilterBar />

        {loading ? (
          <div className="flex flex-col items-center justify-center py-32 space-y-6">
            <div className="w-12 h-12 border-4 border-[#ffd875] border-t-transparent rounded-full animate-spin"></div>
            <p className="text-[#ffd875]/40 animate-pulse text-xs font-black uppercase tracking-[0.3em]">
              Hệ não đang đồng bộ danh mục...
            </p>
          </div>
        ) : movies.length === 0 ? (
          <div className="py-24 text-center text-white/40 text-sm font-bold uppercase tracking-widest">
            Không tìm thấy phim cho chủ đề này
          </div>
        ) : (
          <InfiniteMovieGrid
            initialItems={movies}
            initialTotalPages={totalPages}
            initialPage={3}
            fetchMore={(page: number) => fetchBySlug(slug, page)}
          />
        )}
      </div>
    </main>
  );
}